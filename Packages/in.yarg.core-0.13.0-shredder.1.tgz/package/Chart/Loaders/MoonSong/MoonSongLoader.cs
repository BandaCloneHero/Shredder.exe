﻿using System;
using System.Collections.Generic;
using System.IO;
using Melanchall.DryWetMidi.Core;
using MoonscraperChartEditor.Song;
using MoonscraperChartEditor.Song.IO;
using YARG.Core.Chart.Events;
using YARG.Core.Logging;
using YARG.Core.Parsing;

namespace YARG.Core.Chart
{
    using CurrentPhrases = Dictionary<MoonPhrase.Type, MoonPhrase>;

    /// <summary>
    /// Loads chart data from a MoonSong.
    /// </summary>
    internal partial class MoonSongLoader : ISongLoader
    {
        private delegate TNote CreateNoteDelegate<TNote>(MoonNote moonNote, CurrentPhrases currentPhrases, List<TNote> notes)
            where TNote : Note<TNote>;
        private delegate void ProcessTextDelegate(MoonText text);
        private delegate Phrase? ValidatePhraseDelegate(Phrase phrase, List<Phrase> phrases);
        private delegate void FinalPassDelegate<TNote>(InstrumentDifficulty<TNote> chart) where TNote : Note<TNote>;

        private MoonSong _moonSong;
        private ParseSettings _settings;
        // .chart format uses inclusive solo phrase boundaries (the note at phrase end tick is inside the solo);
        // .mid format uses exclusive boundaries. Other formats should set this based on their own spec.
        private bool _inclusiveSoloBoundary;

        private GameMode _currentMode;
        private Instrument _currentInstrument;
        private Difficulty _currentDifficulty;

        private MoonChart.GameMode _currentMoonMode;
        private MoonSong.MoonInstrument _currentMoonInstrument;
        private MoonSong.Difficulty _currentMoonDifficulty;

        private readonly double _codaTime;
        private readonly List<(uint start,uint end)> _codaTicks;

        private enum LaneParsingState
        {
            None,
            Tremolo,
            Trill
        }

        public MoonSongLoader(MoonSong song, in ParseSettings settings)
        {
            _moonSong = song;
            _settings = settings;
            _codaTime = FindCodaTime();
            _codaTicks = GetCodaTicks();
        }

        public static MoonSongLoader LoadSong(ParseSettings settings, string filePath)
        {
            bool isChart = Path.GetExtension(filePath).ToLower() switch
            {
                ".mid"   => false,
                ".chart" => true,
                _ => throw new ArgumentException($"Unrecognized file extension for chart path '{filePath}'!", nameof(filePath))
            };

            var song = isChart
                ? ChartReader.ReadFromFile(ref settings, filePath)
                : MidReader.ReadMidi(ref settings, filePath);

            return new(song, settings) { _inclusiveSoloBoundary = isChart };
        }

        public static MoonSongLoader LoadMidi(ParseSettings settings, MidiFile midi)
        {
            var song = MidReader.ReadMidi(ref settings, midi);
            return new(song, settings);
        }

        public static MoonSongLoader LoadDotChart(ParseSettings settings, ReadOnlySpan<char> chartText)
        {
            // Reading from a .chart *file* is handled in LoadSong, and checks the extension
            // This path reads from data already in-memory, which we know is '.chart', so this is hardcoded
            var song = ChartReader.ReadFromText(ref settings, chartText);
            return new(song, settings)  { _inclusiveSoloBoundary = true };
        }

        public List<TextEvent> LoadGlobalEvents()
        {
            var textEvents = new List<TextEvent>(_moonSong.events.Count);
            foreach (var moonText in _moonSong.events)
            {
                double time = _moonSong.TickToTime(moonText.tick);
                var newText = new TextEvent(moonText.text, time, moonText.tick);
                textEvents.Add(newText);
            }

            return textEvents;
        }

        public List<CharacterState> LoadCharacterStates(MoonChart moonChart)
        {
            var characterStates = new List<CharacterState>();



            return characterStates;
        }

        public List<HandMap> LoadHandMaps() => new List<HandMap>();

        public List<StrumMap> LoadStrumMaps() => new List<StrumMap>();

        public List<Section> LoadSections()
        {
            var sections = new List<Section>();

            for (var i = 0; i < _moonSong.sections.Count;)
            {
                var moonSection = _moonSong.sections[i];
                double time = _moonSong.TickToTime(moonSection.tick);
                sections.Add(new Section(moonSection.text, time, moonSection.tick));

                if (++i < _moonSong.sections.Count)
                {
                    double next = _moonSong.TickToTime(_moonSong.sections[i].tick);
                    sections[^1].TimeLength = next - time;
                    sections[^1].TickLength = _moonSong.sections[i].tick - moonSection.tick;
                }
            }

            return sections;
        }

        public SyncTrack LoadSyncTrack()
        {
            return _moonSong.syncTrack;
        }

        private InstrumentDifficulty<TNote> LoadDifficulty<TNote>(
            Instrument instrument,
            Difficulty difficulty,
            CreateNoteDelegate<TNote> createNote,
            ProcessTextDelegate? processText = null,
            ValidatePhraseDelegate? validatePhrase = null,
            FinalPassDelegate<TNote>? finalPassDelegate = null)
            where TNote : Note<TNote>
        {
            _currentMode = instrument.ToNativeGameMode();
            _currentInstrument = instrument;
            _currentDifficulty = difficulty;

            _currentMoonMode = YargGameModeToMoonGameMode(_currentMode);
            _currentMoonInstrument = YargInstrumentToMoonInstrument(_currentInstrument);
            _currentMoonDifficulty = YargDifficultyToMoonDifficulty(_currentDifficulty);

            var moonChart = GetMoonChart(instrument, difficulty);
            var notes = GetNotes(moonChart, difficulty, createNote, processText);
            var phrases = GetPhrases(moonChart, validatePhrase);
            var textEvents = GetTextEvents(moonChart);

            var chart = new InstrumentDifficulty<TNote>(instrument, difficulty, notes, phrases, textEvents);

            if (finalPassDelegate is not null)
            {
                finalPassDelegate(chart);
            }

            return chart;
        }

        private List<TNote> GetNotes<TNote>(MoonChart moonChart, Difficulty difficulty,
            CreateNoteDelegate<TNote> createNote, ProcessTextDelegate? processText = null)
            where TNote : Note<TNote>
        {
            var notes = new List<TNote>(moonChart.notes.Count);

            int moonPhraseIndex = 0;
            int moonTextIndex = 0;

            // Phrases stored here are *not* guaranteed to be active, as it's simpler that way
            // We need to check the phrase bounds anyways, which is very simple to do
            var currentPhrases = new CurrentPhrases();

            foreach (var moonNote in moonChart.notes)
            {
                // Keep track of active special phrases
                while (moonPhraseIndex < moonChart.specialPhrases.Count)
                {
                    var moonPhrase = moonChart.specialPhrases[moonPhraseIndex];
                    if (moonPhrase.tick > moonNote.tick)
                        break;

                    currentPhrases[moonPhrase.type] = moonPhrase;
                    moonPhraseIndex++;
                }

                // Send through text events, if requested
                if (processText != null)
                {
                    while (moonTextIndex < moonChart.events.Count)
                    {
                        var moonText = moonChart.events[moonTextIndex];
                        if (moonText.tick > moonNote.tick)
                            break;

                        processText(moonText);
                        moonTextIndex++;
                    }
                }

                // Skip Expert+ notes if not on Expert+
                if (difficulty != Difficulty.ExpertPlus && (moonNote.flags & MoonNote.Flags.InstrumentPlus) != 0)
                {
                    continue;
                }

                var newNote = createNote(moonNote, currentPhrases, notes);
                AddNoteToList(notes, newNote);
            }

            notes.TrimExcess();
            return notes;
        }

        private List<Phrase> GetPhrases(MoonChart moonChart, ValidatePhraseDelegate? validatePhrase = null)
        {
            var phrases = new List<Phrase>(moonChart.specialPhrases.Count);
            foreach (var moonPhrase in moonChart.specialPhrases)
            {
                PhraseType? phraseType = moonPhrase.type switch
                {
                    MoonPhrase.Type.Starpower           => PhraseType.StarPower,
                    MoonPhrase.Type.Solo                => PhraseType.Solo,
                    MoonPhrase.Type.Versus_Player1      => PhraseType.VersusPlayer1,
                    MoonPhrase.Type.Versus_Player2      => PhraseType.VersusPlayer2,
                    MoonPhrase.Type.TremoloLane         => PhraseType.TremoloLane,
                    MoonPhrase.Type.TrillLane           => PhraseType.TrillLane,
                    MoonPhrase.Type.BigRockEnding       => PhraseType.BigRockEnding,
                    MoonPhrase.Type.Coda                => PhraseType.Coda,

                    MoonPhrase.Type.ProDrums_Activation => PhraseType.DrumFill,

                    MoonPhrase.Type.ProKeys_RangeShift0 => PhraseType.ProKeys_RangeShift0,
                    MoonPhrase.Type.ProKeys_RangeShift1 => PhraseType.ProKeys_RangeShift1,
                    MoonPhrase.Type.ProKeys_RangeShift2 => PhraseType.ProKeys_RangeShift2,
                    MoonPhrase.Type.ProKeys_RangeShift3 => PhraseType.ProKeys_RangeShift3,
                    MoonPhrase.Type.ProKeys_RangeShift4 => PhraseType.ProKeys_RangeShift4,
                    MoonPhrase.Type.ProKeys_RangeShift5 => PhraseType.ProKeys_RangeShift5,

                    MoonPhrase.Type.EliteDrums_DiscoFlip => PhraseType.EliteDrums_DiscoFlip,

                    _ => null
                };

                if (!phraseType.HasValue)
                {
                    continue;
                }

                double time = _moonSong.TickToTime(moonPhrase.tick);
                var newPhrase = new Phrase(phraseType.Value, time, GetLengthInTime(moonPhrase), moonPhrase.tick, moonPhrase.length);

                if (validatePhrase == null)
                {
                    phrases.Add(newPhrase);
                    continue;
                }

                var validatedPhrase = validatePhrase(newPhrase, phrases);
                if (validatedPhrase != null)
                {
                    phrases.Add(validatedPhrase);
                }
            }

            return phrases;
        }

        private List<TextEvent> GetTextEvents(MoonChart moonChart)
        {
            var textEvents = new List<TextEvent>(moonChart.events.Count);
            foreach (var moonText in moonChart.events)
            {
                double time = _moonSong.TickToTime(moonText.tick);
                var newText = new TextEvent(moonText.text, time, moonText.tick);
                textEvents.Add(newText);
            }

            return textEvents;
        }

        private NoteFlags GetGeneralFlags(MoonNote moonNote, CurrentPhrases currentPhrases)
        {
            // In most cases, eligibility for trills simply means not being a chord
            // Drums needs its own check to make exceptions for kicks
            static bool DefaultTrillEligibilityCheck(MoonNote moonNote)
            {
                return !moonNote.isChord;
            }

            return GetGeneralFlags(moonNote, currentPhrases, DefaultTrillEligibilityCheck);
        }

        private NoteFlags GetGeneralFlags(MoonNote moonNote, CurrentPhrases currentPhrases, Func<MoonNote,bool> isEligibleForTrill)
        {
            var flags = NoteFlags.None;

            var previous = moonNote.PreviousSeperateMoonNote;
            var next = moonNote.NextSeperateMoonNote;

            // Star power
            if (currentPhrases.TryGetValue(MoonPhrase.Type.Starpower, out var starPower) && IsEventInPhrase(moonNote, starPower, inclusiveEnd: false))
            {
                flags |= NoteFlags.StarPower;

                if (previous == null || !IsEventInPhrase(previous, starPower, inclusiveEnd: false))
                {
                    flags |= NoteFlags.StarPowerStart;
                }

                if (next == null || !IsEventInPhrase(next, starPower, inclusiveEnd: false))
                {
                    flags |= NoteFlags.StarPowerEnd;
                }
            }

            // Solos
            if (currentPhrases.TryGetValue(MoonPhrase.Type.Solo, out var solo) && IsEventInPhrase(moonNote, solo, inclusiveEnd: _inclusiveSoloBoundary))
            {
                flags |= NoteFlags.Solo;

                if (previous == null || !IsEventInPhrase(previous, solo, inclusiveEnd: _inclusiveSoloBoundary))
                {
                    flags |= NoteFlags.SoloStart;
                }

                if (next == null || !IsEventInPhrase(next, solo, inclusiveEnd: _inclusiveSoloBoundary))
                {
                    flags |= NoteFlags.SoloEnd;
                }
            }

            // Big Rock Ending
            // End-inclusive: a note charted on the exact tick where the BRE ends is still
            // covered by the BRE lanes and must be suppressed, not treated as a normal note.
            if (currentPhrases.TryGetValue(MoonPhrase.Type.BigRockEnding, out var bigRockEnding) &&
                IsEventInPhrase(moonNote, bigRockEnding, inclusiveEnd: true))
            {
                flags |= NoteFlags.BigRockEnding;
            }

            // Coda End (this one is weird because creating a MoonPhrase from text events seems hard so we set the flag
            // in postproc)
            if ((moonNote.flags & MoonNote.Flags.CodaEnd) != 0)
            {
                flags |= NoteFlags.CodaEnd;
            }

            // Trill and tremolo lanes are handled in the finalPassDelegate, since they're easiest to parse with Notes instead of MoonNotes

            return flags;
        }

        private void AddNoteToList<TNote>(List<TNote> notes, TNote note)
            where TNote : Note<TNote>
        {
            // The parent of all notes on the current tick
            var currentParent = notes.Count > 0 ? notes[^1] : null;
            // Previous parent note (on a different tick)
            var previousParent = notes.Count > 1 ? notes[^2] : null;

            // If we are not a laned note and the previous note is a laned note without a lane end flag
            // add the lane end flag to that previous note
            // if (!note.IsLane && currentParent is { IsLane: true, IsLaneEnd: false })
            // {
            //     currentParent.ActivateFlag(NoteFlags.LaneEnd);
            // }

            // Determine if this is part of a chord
            if (currentParent != null)
            {
                if (note.Tick == currentParent.Tick)
                {
                    // Same chord, assign previous and add as child
                    note.PreviousNote = previousParent;
                    currentParent.AddChildNote(note);
                    return;
                }
                else if ((note.Tick - currentParent.Tick) <= _settings.NoteSnapThreshold)
                {
                    // Chord needs to be snapped, copy values
                    note.CopyValuesFrom(currentParent);

                    note.PreviousNote = previousParent;
                    currentParent.AddChildNote(note);
                    return;
                }
            }

            // New chord
            previousParent = currentParent;
            currentParent = note;

            // Assign next/previous note references
            if (previousParent is not null)
            {
                previousParent.NextNote = currentParent;
                foreach (var child in previousParent.ChildNotes)
                    child.NextNote = currentParent;

                currentParent.PreviousNote = previousParent;
            }

            notes.Add(note);
        }

        private double GetLengthInTime(double startTime, uint tick, uint tickLength)
        {
            return _moonSong.TickToTime(tick + tickLength) - startTime;
        }

        private double GetLengthInTime(MoonNote note)
        {
            double time = _moonSong.TickToTime(note.tick);
            return GetLengthInTime(time, note.tick, note.length);
        }

        private double GetLengthInTime(MoonPhrase phrase)
        {
            double time = _moonSong.TickToTime(phrase.tick);
            return GetLengthInTime(time, phrase.tick, phrase.length);
        }

        private double GetLengthInTime(MoonAnimation animation)
        {
            double time = _moonSong.TickToTime(animation.tick);
            return GetLengthInTime(time, animation.tick, animation.length);
        }

        private double FindCodaTime()
        {
            // Work backwards since the coda event should be very near the end
            for (int i = _moonSong.events.Count - 1; i >= 0; i--)
            {
                if (_moonSong.events[i].text != MidIOHelper.CODA_START)
                {
                    continue;
                }

                return _moonSong.TickToTime(_moonSong.events[i].tick);
            }

            // Didn't find one, so set it to MaxValue
            return double.MaxValue;
        }

        private List<(uint,uint)> GetCodaTicks()
        {
            return MidReader.GetCodaRanges(_moonSong);
        }

        private static bool IsEventInPhrase(MoonObject songObj, MoonPhrase phrase,
            bool inclusiveEnd = false)
        {
            if (songObj == null || phrase == null)
            {
                YargLogger.Assert(songObj != null, "Null event received");
                YargLogger.Assert(phrase != null, "Null phrase received");
                return false;
            }

            // Ensure 0-length phrases still take effect
            // (e.g. the SP phrases at the end of ExileLord - Hellidox)
            if (phrase.length == 0)
                return songObj.tick == phrase.tick;

            return inclusiveEnd
                ? phrase.tick <= songObj.tick && songObj.tick <= (phrase.tick + phrase.length)
                : phrase.tick <= songObj.tick && songObj.tick <  (phrase.tick + phrase.length);
        }

        // REMOVED: IsNoteClosestToEndOfPhrase
        // Removal date: 2026-04-14
        // This method worked around the exclusive end boundary in IsEventInPhrase() using
        // distance-based logic to find notes closest to phrase ends. It had zero callers
        // in YARG.Core or the Unity project. The root cause is now fixed by the inclusiveEnd
        // parameter on IsEventInPhrase(). Restore from git history if needed.

        private MoonChart GetMoonChart(Instrument instrument, Difficulty difficulty)
        {
            var moonInstrument = YargInstrumentToMoonInstrument(instrument);
            var moonDifficulty = YargDifficultyToMoonDifficulty(difficulty);
            return _moonSong.GetChart(moonInstrument, moonDifficulty);
        }

        private static MoonChart.GameMode YargGameModeToMoonGameMode(GameMode mode) => mode switch
        {
            GameMode.FiveFretGuitar => MoonChart.GameMode.Guitar,
            GameMode.SixFretGuitar => MoonChart.GameMode.GHLGuitar,

            GameMode.FourLaneDrums => MoonChart.GameMode.Drums,
            GameMode.FiveLaneDrums => MoonChart.GameMode.Drums,
            GameMode.EliteDrums => MoonChart.GameMode.EliteDrums,

            GameMode.ProGuitar => MoonChart.GameMode.ProGuitar,
            GameMode.ProKeys => MoonChart.GameMode.ProKeys,

            GameMode.Vocals => MoonChart.GameMode.Vocals,

            _ => throw new NotImplementedException($"Unhandled game mode {mode}!")
        };

        private static MoonSong.MoonInstrument YargInstrumentToMoonInstrument(Instrument instrument) => instrument switch
        {
            Instrument.FiveFretGuitar     => MoonSong.MoonInstrument.Guitar,
            Instrument.FiveFretCoopGuitar => MoonSong.MoonInstrument.GuitarCoop,
            Instrument.FiveFretBass       => MoonSong.MoonInstrument.Bass,
            Instrument.FiveFretRhythm     => MoonSong.MoonInstrument.Rhythm,
            Instrument.Keys               => MoonSong.MoonInstrument.Keys,

            Instrument.SixFretGuitar     => MoonSong.MoonInstrument.GHLiveGuitar,
            Instrument.SixFretCoopGuitar => MoonSong.MoonInstrument.GHLiveBass,
            Instrument.SixFretBass       => MoonSong.MoonInstrument.GHLiveRhythm,
            Instrument.SixFretRhythm     => MoonSong.MoonInstrument.GHLiveCoop,

            Instrument.FourLaneDrums or
            Instrument.FiveLaneDrums or
            Instrument.ProDrums => MoonSong.MoonInstrument.Drums,
            Instrument.EliteDrums => MoonSong.MoonInstrument.EliteDrums,

            Instrument.ProGuitar_17Fret => MoonSong.MoonInstrument.ProGuitar_17Fret,
            Instrument.ProGuitar_22Fret => MoonSong.MoonInstrument.ProGuitar_22Fret,
            Instrument.ProBass_17Fret   => MoonSong.MoonInstrument.ProBass_17Fret,
            Instrument.ProBass_22Fret   => MoonSong.MoonInstrument.ProBass_22Fret,

            Instrument.ProKeys => MoonSong.MoonInstrument.ProKeys,

            // Vocals and harmony need to be handled specially
            // Instrument.Vocals  => MoonSong.MoonInstrument.Vocals,
            // Instrument.Harmony => MoonSong.MoonInstrument.Harmony1,

            _ => throw new NotImplementedException($"Unhandled instrument {instrument}!")
        };

        private static MoonSong.Difficulty YargDifficultyToMoonDifficulty(Difficulty difficulty) => difficulty switch
        {
            Difficulty.Beginner or
            Difficulty.Easy       => MoonSong.Difficulty.Easy,
            Difficulty.Medium     => MoonSong.Difficulty.Medium,
            Difficulty.Hard       => MoonSong.Difficulty.Hard,
            Difficulty.Expert or
            Difficulty.ExpertPlus => MoonSong.Difficulty.Expert,
            _ => throw new InvalidOperationException($"Invalid difficulty {difficulty}!")
        };

        private static List<TNote> GetNotesInLanePhrase<TNote>(List<Phrase> phrases, int phraseIndex, List<TNote> allNotes, int startingIndex, out int nextIndex) where TNote : Note<TNote>
        {
            var phrase = phrases[phraseIndex];

            var conterminousNextLaneExists = false;
            // Find the next lane phrase, if any. If it exists and its start tick is the same as this phrase's end tick, then we'll treat this phrase as
            // end-tick-exclusive to give the subsequent lane ownership of any note on that tick
            for (var i = phraseIndex; i < phrases.Count; i++)
            {
                var laterPhrase = phrases[i];

                if (laterPhrase.Tick > phrase.TickEnd)
                {
                    // We've moved on to phrases that don't abut this one; there is no conterminous next lane
                    break;
                }

                if (laterPhrase.Tick == phrase.TickEnd && laterPhrase.Type is PhraseType.TremoloLane or PhraseType.TrillLane)
                {
                    conterminousNextLaneExists = true;
                    break;
                }
            }


            List<TNote> notesInPhrase = new();

            nextIndex = startingIndex;

            for (var i = startingIndex; i < allNotes.Count; i++)
            {
                var note = allNotes[i];

                if (note.Tick < phrase.Tick)
                {
                    continue;
                }

                if (conterminousNextLaneExists && note.Tick == phrase.TickEnd)
                {
                    // If there's a conterminous next lane, then this lane phrase excludes its last tick and gives it to that subsequent phrase instead
                    break;
                }

                if (note.Tick > phrase.TickEnd)
                {
                    break;
                }

                nextIndex = i + 1; // This is where the next GetNotesInPhrase call will start iterating from, so we don't waste time rescanning earlier notes again
                notesInPhrase.Add(note);
            }

            return notesInPhrase;
        }
    }
}