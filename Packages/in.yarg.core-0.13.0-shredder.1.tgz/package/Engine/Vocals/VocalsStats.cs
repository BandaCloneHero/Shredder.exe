﻿using System;
using System.Collections.Generic;
using System.IO;
using YARG.Core.Extensions;
using YARG.Core.IO;
using YARG.Core.Replays;

namespace YARG.Core.Engine.Vocals
{
    public class VocalsStats : BaseStats
    {
        /// <summary>
        /// The amount of note ticks that was hit by the vocalist.
        /// </summary>
        public uint TicksHit;

        /// <summary>
        /// The amount of note ticks that were missed by the vocalist.
        /// </summary>
        public uint TicksMissed;

        /// <summary>
        /// The total amount of note ticks.
        /// </summary>
        public uint TotalTicks => TicksHit + TicksMissed;

        public bool HasCarryNote;

        public override float Percent => TotalTicks == 0 ? 1f : (float) TicksHit / TotalTicks;

        public override int BandComboUnits => 10;

        public VocalsStats()
        {
        }

        public VocalsStats(VocalsStats stats) : base(stats)
        {
            TicksHit = stats.TicksHit;
            TicksMissed = stats.TicksMissed;
            HasCarryNote = stats.HasCarryNote;
        }

        public VocalsStats(ref FixedArrayStream stream, int version)
            : base(ref stream, version)
        {
            TicksHit = stream.Read<uint>(Endianness.Little);
            TicksMissed = stream.Read<uint>(Endianness.Little);
            HasCarryNote = stream.ReadBoolean();
        }

        public override void Reset()
        {
            base.Reset();
            TicksHit = 0;
            TicksMissed = 0;
            HasCarryNote = false;
        }

        public override IReadOnlyList<double> GetOffsetSamples()
        {
            return Array.Empty<double>();
        }

        public override void Serialize(BinaryWriter writer)
        {
            base.Serialize(writer);

            writer.Write(TicksHit);
            writer.Write(TicksMissed);
            writer.Write(HasCarryNote);
        }

        public override ReplayStats ConstructReplayStats(string name, bool isReplayPlayer)
        {
            return new VocalsReplayStats(name, isReplayPlayer, this);
        }
    }
}